#include <stdio.h>
#include "frame.h"

int main(){
    Segment s1;

    initSegment(&s1,10,'a');
}